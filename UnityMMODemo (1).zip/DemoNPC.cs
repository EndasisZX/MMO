using UnityEngine;
using UnityEngine.UI;

public class DemoNPC : MonoBehaviour
{
    public string npcName = "Elder";
    public string[] dialogueLines = {
        "Greetings, traveler!",
        "I have a quest for you.",
        "Please collect 3 magical herbs."
    };

    public GameObject dialoguePanel;
    public Text dialogueText;
    public Button acceptButton;

    private int currentLine = 0;
    private bool questAccepted = false;

    void Start()
    {
        dialoguePanel.SetActive(false);
        acceptButton.onClick.AddListener(AcceptQuest);
    }

    void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("Player"))
        {
            dialoguePanel.SetActive(true);
            currentLine = 0;
            ShowLine();
        }
    }

    void OnTriggerExit(Collider other)
    {
        if (other.CompareTag("Player"))
        {
            dialoguePanel.SetActive(false);
        }
    }

    public void ShowLine()
    {
        dialogueText.text = dialogueLines[currentLine];
        acceptButton.gameObject.SetActive(currentLine == dialogueLines.Length - 1 && !questAccepted);
    }

    public void NextLine()
    {
        if (currentLine < dialogueLines.Length - 1)
        {
            currentLine++;
            ShowLine();
        }
    }

    public void AcceptQuest()
    {
        questAccepted = true;
        dialoguePanel.SetActive(false);
        Debug.Log("Quest accepted!");
        // Trigger quest logic here
    }
}