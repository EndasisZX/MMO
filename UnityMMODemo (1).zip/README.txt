Unity MMO Demo Package
---------------------

Included scripts:
- PlayerMovement.cs: Basic player movement with WASD/arrow keys.
- DemoNPC.cs: NPC that triggers dialogue and quest acceptance UI.
- CheckmarkEffect.cs: Plays particle and sound effects when a quest objective is completed.

Setup Instructions:
1. Import this package into your Unity project (Assets > Import Package > Custom Package).
2. Create a new Scene named 'DemoScene' and add:
   - A Plane for ground.
   - A Capsule for Player, tag it "Player", add PlayerMovement script.
   - A Cube for NPC, add BoxCollider (Is Trigger), add DemoNPC script.
   - Create Canvas with Panel for dialogue, add Text and Button, link references in DemoNPC inspector.
   - Add Checkmark prefab with CheckmarkEffect script to your UI for quest objectives.
3. Press Play and approach the NPC to start dialogue and accept a quest.

Note: This is a minimal setup to demonstrate the core mechanics.

Enjoy your fantasy MMO demo!