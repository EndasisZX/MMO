using UnityEngine;

public class CheckmarkEffect : MonoBehaviour
{
    public AudioClip popSound;
    public ParticleSystem sparkleEffect;
    private AudioSource audioSource;

    void Awake()
    {
        audioSource = GetComponent<AudioSource>();
    }

    public void PlayEffect()
    {
        gameObject.SetActive(true);
        StartCoroutine(ScalePop());
        if (popSound != null)
        {
            audioSource.PlayOneShot(popSound);
        }
        if (sparkleEffect != null)
        {
            sparkleEffect.Play();
        }
    }

    System.Collections.IEnumerator ScalePop()
    {
        Vector3 originalScale = transform.localScale;
        transform.localScale = Vector3.zero;
        float timer = 0f;
        float duration = 0.3f;
        while (timer < duration)
        {
            transform.localScale = Vector3.Lerp(Vector3.zero, originalScale, timer / duration);
            timer += Time.deltaTime;
            yield return null;
        }
        transform.localScale = originalScale;
    }
}